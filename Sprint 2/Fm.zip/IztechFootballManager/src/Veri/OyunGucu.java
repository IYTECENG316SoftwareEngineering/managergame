package Veri;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class OyunGucu {
	public static ArrayList<String> list = new ArrayList<String>();
	
	public static void gucCek(String tablo,String al�nacakBilgi,String al�nacakBilgi2,String al�nacakBilgi3,String al�nacakBilgi4) throws SQLException  {
		
		list.clear();
		System.out.println("-------- PLAYER NAME ------");
 
		try {
 
			Class.forName("oracle.jdbc.driver.OracleDriver");
 
		} catch (ClassNotFoundException e) {
			System.out.println("NOT FOUND");
			e.printStackTrace();
		} 
		System.out.println("G�R�L�YOR...");
 
		Connection connection = null;
 
		try {
 
			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "FMIYTE", "fmiyte");
 
		} catch (SQLException e) {
 
			System.out.println("CONNECTION PROBLEM");
			e.printStackTrace();
	
		}
 
		if (connection != null) {
			System.out.println("SUCCESFUL");
			Statement stat=connection.createStatement();
			String query=tablo;
			ResultSet resultset=stat.executeQuery(query);
			while(resultset.next()){

						list.add(resultset.getString(al�nacakBilgi));
						list.add(resultset.getString(al�nacakBilgi2));
						list.add(resultset.getString(al�nacakBilgi3));
						list.add(resultset.getString(al�nacakBilgi4));
						
			}		
			connection.close();
		} else {
			System.out.println("VER� �EK�LEM�YOR:");
		}		
	}

}
