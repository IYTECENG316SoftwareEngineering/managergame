package Veri;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class TransferVeri {
	public static ArrayList<String> list = new ArrayList<String>();
	static int se�ilentakim=2;
	static int budget = 0;
	static int �ncekiclub_id = 0;
	static int playerPrice = 0;
	
	public static void transferYap(String al�nacakBilgi2,String al�nacakBilgi) throws SQLException  {
		
		list.clear();
		System.out.println("-------- PLAYER NAME ------");
		int se�ilenOyuncuId=Integer.parseInt(al�nacakBilgi);
			try {
	 
				Class.forName("oracle.jdbc.driver.OracleDriver");
	 
			} catch (ClassNotFoundException e) {
				System.out.println("NOT FOUND");
				e.printStackTrace();
			} 
		System.out.println("G�R�L�YOR...");
 
		Connection connection = null;
 
		try {
 
			connection = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "FMIYTE", "fmiyte");
 
		} catch (SQLException e) {
 
			System.out.println("CONNECTION PROBLEM");
			e.printStackTrace();
	
		}
 
		if (connection != null) {
			System.out.println("SUCCESFUL");
			Statement stat=connection.createStatement();
			String query2="SELECT budget FROM club WHERE idclub ="+ "(SELECT club_idclub FROM player WHERE player_id ="+se�ilenOyuncuId+")";
			ResultSet rs1=stat.executeQuery(query2);
			while(rs1.next()){
			budget =rs1.getInt("budget");
								}
			
			String query3="SELECT club_idclub FROM player WHERE player_id ="+se�ilenOyuncuId;
			ResultSet rs2=stat.executeQuery(query3);
			while(rs2.next()){
			�ncekiclub_id =rs2.getInt("club_idclub");
								}
			String query5="SELECT transfer_value FROM player WHERE player_id ="+se�ilenOyuncuId;
			ResultSet rs4=stat.executeQuery(query5);
			while(rs4.next()){
			playerPrice =rs4.getInt("transfer_value");
								}
			
			String query4="UPDATE budget SET budget =" +(budget-playerPrice)+"WHERE idclub="+�ncekiclub_id;
			Statement ps2 = connection.createStatement( );
			int rs3=ps2.executeUpdate(query4);
			
			
			String query="UPDATE player " +
				    "SET club_idclub = "+se�ilentakim +" WHERE player_id= "+ se�ilenOyuncuId;
			Statement ps = connection.createStatement( );
			int rs=ps.executeUpdate(query);
			connection.close();
			}		
			connection.close();
		
			
	}


}

