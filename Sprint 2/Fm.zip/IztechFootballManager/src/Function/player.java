package Function;



public class player {
	
	int player_id;
	int club_idclub;
	int uniform_no;
	String name;
	String surname;
	int age;
	String nation;
	int goalkeeping;
	int defence ;
	int passing;
	int attack;
	int transfer_value;
	
	public player (int a , int b , int c ,String d ,String e, int x, String y ,int g ,int de ,int p ,int at,int t){
		this.player_id =a;
		this.club_idclub=b;
		this.uniform_no=c;
		this.name=d;
		this.surname=e;
		this.age=x;
		this.nation=y;
		this.goalkeeping=g;
		this.defence=de;
		this.passing=p;
		this.attack=at;
		this.transfer_value=t;
	}
}
	
	
	