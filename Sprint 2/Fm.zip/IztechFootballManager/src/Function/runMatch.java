package Function;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
public class runMatch {
/*public static void main(String[] args) throws SQLException, ClassNotFoundException {
		//sortB�y�ktenK����e(ilk11Kendili�inden(kadro("FENER")));
		
		ma�("FENER","GALAT");
		}*/
	

public static int getTakim_id(String takim_name) throws ClassNotFoundException, SQLException{
	int retur = 0;
	Class.forName("com.mysql.jdbc.Driver");
	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/iytefm","byosko","byosko");
	Statement stat=conn.createStatement();
	String query="Select * from club where club_name LIKE '%"+ takim_name +"%'";
	ResultSet rs=stat.executeQuery(query);
	while(rs.next()){
		retur= rs.getInt("idclub");
		
	}conn.close();
	return retur;
}
// �al�s�yo ama name i surname yapsak daha dogru olabilir ve k���k b�y�k harfe hassas
public static int  getPlayer_id(String name , int uniform_no) throws SQLException, ClassNotFoundException{
	int retur = 0;
	Class.forName("com.mysql.jdbc.Driver");
	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/iytefm","byosko","byosko");
	Statement stat=conn.createStatement();
	String query="Select * from player where name LIKE '%"+ name +"%' AND uniform_no = "+ uniform_no;
	
	ResultSet rs=stat.executeQuery(query);
	while(rs.next()){
	retur =rs.getInt("player_id");
	}conn.close();
	return retur;
}
//oyuncunun tak�m id sini update ediyo �al�s�yo

// tak�m�n oyuncular� inin  arraya at�p onu donduruyo bunu player 22 yapt�m ! 
//�al�s�yo her tak�m�n oyuncu say�s�n� tutan array yap sonra
public static player [] kadro(String takim_name) throws ClassNotFoundException, SQLException{
	 player a[] = new player[21];
	
	 Class.forName("com.mysql.jdbc.Driver");
	 Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/iytefm","byosko","byosko");
	 Statement stat=conn.createStatement();
	 String query="select * from player where club_idclub ="+getTakim_id(takim_name);
	 ResultSet rs=stat.executeQuery(query);	
	 int index=0;
	
	 while(rs.next()){
		// System.out.println(rs.getString("name")+ "-----"+rs.getInt("goalkeeping") + "--------------"+ rs.getInt("club_idclub") );
			a[index] =new player(rs.getInt("player_id"),rs.getInt("club_idclub"),rs.getInt("uniform_no"),
								rs.getString("name"),rs.getString("surname"),rs.getInt("age"),rs.getString("nation"),
								rs.getInt("goalkeeping"),rs.getInt("defence"),rs.getInt("passing"),rs.getInt("attack"),
								rs.getInt("transfer_value"));
			
			index++;
			}conn.close();
			
	 return a;
}
public static player golAtan(player[] kadro){
    player[] temp =sortB�y�ktenK����e(kadro);//kadro ;
  /*  for(int i=0;i<11;i++)
    System.out.println(temp[i].attack+ "   "+temp[i].name);*/
    Random rand = new Random();
    int  n = rand.nextInt(100);
    if(n<20)	return temp[0];
    else if (n<35) return temp[1];
    else if (n<45) return temp[2];
    else if (n<50) return temp[3];
    else if (n<57) return temp[4];
    else if (n<70) return temp[5];
    else if (n<78) return temp[6];
    else if (n<85) return temp[7];
    else if (n<90) return temp[8];
    else if (n<95) return temp[9];
    else if (n<100)return temp[10];
  /*  else {
    	n=rand.nextInt(kadro.length-3);
    			return temp[n];
    }*/
	return temp[11];
}
//burda null pointer al�yom sonra bak lengt 22 diye sorun c�k�yo sonra buuble sort a �evir
public static player[] sortB�y�ktenK����e (player [] kadro ){

	 for(int i =0 ; i<11; i++){
			for(int k =0; k <10 ; k++){
				if(kadro[k].attack < kadro[k+1].attack ){
					player temp = kadro[k+1];
					kadro[k+1]=kadro[k];
					kadro[k]=temp;
				}
			}}
	 
	return kadro;
}

public static int[] powerOfTeam(player [] kadro){
	int attack=0;
	int defence=0;
	int pass=0;
	int retur[]= new int[3];

	for(int i=0;i<11;i++){
		player oyuncu=kadro[i];
		attack+=oyuncu.attack;
		defence+=oyuncu.defence;
	    pass+=oyuncu.passing;
		
	}
	retur[0]=attack/kadro.length;
	retur[1]=pass/kadro.length;
	retur[2]=defence/kadro.length;
	return retur;
}

public static player[] ilk11Kendili�inden(player[] fullKadro){
	player[] ilk11=new player[11];
	player[] temp =new player[4];
	
	ilk11[0]=bestKeeper(fullKadro);
	temp=bestDefence(fullKadro);
	for(int i=0;i<4;i++){
		ilk11[i+1]=temp[i];
	}
	temp=bestOrt(fullKadro);
	for(int i=0;i<4;i++){
		ilk11[i+5]=temp[i];
	}
	temp=bestForvet(fullKadro);
	for(int i=0;i<2;i++){
		ilk11[i+9]=temp[i];
	}
	
	
	return ilk11;
}
public static player bestKeeper(player [] kadro ) {
	
		for(int i =0 ; i<19; i++){
			for(int k =0; k <18 ; k++){
				if(kadro[k].goalkeeping <kadro[k+1].goalkeeping  )
				{
					player temp = kadro[k+1];
					kadro[k+1]=kadro[k];
					kadro[k]=temp;
				}
			}
			
		}
		
		player a=kadro[0];

		return a;
	}
public static player[] bestDefence(player [] kadro ) {
	 
		for(int i =0 ; i<18; i++){
			for(int k =0; k <17 ; k++){
				if(kadro[k].defence <kadro[k+1].defence )
				{
					player temp = kadro[k+1];
					kadro[k+1]=kadro[k];
					kadro[k]=temp;
				}
			}
			
		}
		player [] newKadro=new player[4];
		for(int i=0;i<4;i++){
			newKadro[i]=kadro[i];
			}

		return newKadro;
	}
public static player[] bestOrt(player [] kadro ) {
	 
	for(int i =0 ; i<18; i++){
		for(int k =0; k <17 ; k++){
			if(kadro[k].passing <kadro[k+1].passing )
			{
				player temp = kadro[k+1];
				kadro[k+1]=kadro[k];
				kadro[k]=temp;
			}
		}
		
	}
	player [] newKadro=new player[4];
	for(int i=0;i<4;i++){
		newKadro[i]=kadro[i];
		}

	return newKadro;
}
public static player[] bestForvet(player [] kadro ) {
	 
	for(int i =0 ; i<18; i++){
		for(int k =0; k <17 ; k++){
			if(kadro[k].attack<kadro[k+1].attack )
			{
				player temp = kadro[k+1];
				kadro[k+1]=kadro[k];
				kadro[k]=temp;
			}
		}
	}
	
	player [] newKadro=new player[2];
	for(int i=0;i<2;i++){
		newKadro[i]=kadro[i];
	}

	return newKadro;
}
public static int[] ma�(String team1,String team2) throws ClassNotFoundException, SQLException{
	player[] evSahibiKadro=kadro(team1);
	player[] deplasmanKadro=kadro(team2);
	player[] ilk11Ev=ilk11Kendili�inden(evSahibiKadro);
	player[] ilk11Dep=ilk11Kendili�inden(deplasmanKadro);
	
	int[] g��EvSahibi=powerOfTeam(ilk11Ev);
	int[] g��Deplasman=powerOfTeam(ilk11Dep);
	int[] sonu�=new int [2];
	
	Random rnd=new Random();
	int  zar = rnd.nextInt(100);
	
	
	if((g��EvSahibi[0]-g��Deplasman[2])>(g��Deplasman[0]-g��EvSahibi[2]))
	{
		if(zar<20) sonu�[0]=2;
		else if(zar<50) sonu�[0]=1;
		else if(zar<70) sonu�[0]=0;
		else if(zar<85) sonu�[0]=2;
		else if (zar<95) sonu�[0]=3;
		else if(zar<100) sonu�[0]=4;
		
		zar = rnd.nextInt(100);
		
		if(zar<50) sonu�[1]=0;
		else if(zar<70) sonu�[1]=1;
		else if (zar<95) sonu�[1]=2;
		else if(zar<100) sonu�[1]=3;
		
		
	}
	if((g��EvSahibi[0]-g��Deplasman[2])<(g��Deplasman[0]-g��EvSahibi[2]))
	{
		if(zar<20) sonu�[1]=2;
		else if(zar<50) sonu�[1]=1;
		else if(zar<70) sonu�[1]=0;
		else if(zar<85) sonu�[1]=2;
		else if (zar<95) sonu�[1]=3;
		else if(zar<100) sonu�[1]=4;
	
		zar = rnd.nextInt(100);
	
		if(zar<50) sonu�[0]=0;
		else if(zar<70) sonu�[0]=1;
		else if (zar<95) sonu�[0]=2;
		else if(zar<100) sonu�[0]=3;
	
	}
	
	for(int i=0;i<sonu�[0];i++) System.out.println("Gol� atan oyuncu     "+team1+"      den      "+golAtan(kadro(team1)).name);// gol atan�n forunu sonra 11 yap bunuda ilk 11 yap
	for(int i=0;i<sonu�[1];i++) System.out.println("Gol� atan oyuncu     "+team2+"      den      "+golAtan(kadro(team2)).name);
	return null;
	
}
}
	