package Gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.SystemColor;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import Veri.PlayerName;
import Veri.SadeceIs�m;

import java.awt.Font;

import javax.swing.JRadioButton;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBox;

import java.awt.Choice;

import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.Label;
import java.awt.Color;

public class Stadium extends JFrame {
	private JPanel contentPane;
	String pname2=null;
	String se�ilenTak�m;
	String source;
	List<JCheckBox> buttons = new ArrayList<>();
	
	public Stadium() throws SQLException {
		super("IZTECH FM 15");
	 	this.se�ilenTak�m=NewGame.heptak�m;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 740, 540);
		setVisible(true);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(723, 0, 1, 487);
		panel.setBackground(Color.WHITE);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("Back To Game Menu");
		btnNewButton.setBackground(Color.GRAY);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GameMenu frame = new GameMenu();
				setVisible(false);
				dispose();
			}
		});
		btnNewButton.setBounds(191, 467, 230, 23);
		getContentPane().add(btnNewButton);
		
		String Gonderilen = "SELECT * FROM PLAYER,�DCLUB WHERE CLUB�D=�DCLUB AND CLUB_NAME="+"'"+se�ilenTak�m+"'";
		try {
			SadeceIs�m.Veri�ek2(Gonderilen, "STAD�UM");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		int count = 30;

		for(Object l : SadeceIs�m.list)
		{				
			source=(String)l;
			repaint();		
		}
		
		JLabel StadAd� = new JLabel();
		StadAd�.setForeground(Color.RED);
		StadAd�.setHorizontalAlignment(SwingConstants.CENTER);
		StadAd�.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 45));
		StadAd�.setText(source);
		StadAd�.setBounds(132, 315, 357, 50);
		getContentPane().add(StadAd�);
		StadAd�.setOpaque(false);
		
		JLabel ArkaPlan = new JLabel(new ImageIcon("C:\\Users\\asus\\Desktop\\FMProje\\FMResimler\\stadium.jpg"));
		ArkaPlan.setBounds(0, 0, 724, 501);
		getContentPane().add(ArkaPlan);
		
	
		
	
		

	
	}
}
