package Gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.SystemColor;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import Veri.PlayerName;
import Veri.SadeceIs�m;
import Veri.TransferVeri;

import java.awt.Font;

import javax.swing.JRadioButton;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JCheckBox;

import java.awt.Choice;

import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.Label;
import java.awt.Color;

public class Transfer extends JFrame {
	private JPanel contentPane;
	String pname2=null;
	String se�ilenTak�m;
	int count=19;
	int count2=0;
	JCheckBox source;
	private JTextField txtIlkiSeiniz;
	LinkedList checkList = new LinkedList();
	int sayiDeneme;
	int say�s�11=0;
	List<JCheckBox> buttons = new ArrayList<>();
	String secilenTak�m;
	private JTextField textField;
	String gecici[];
	int arda2;
	private JTextField txtTeamName;
	String TransferIs�m;
	
	public Transfer() throws SQLException {
		super("IZTECH FM 15");
	 	this.se�ilenTak�m=NewGame.heptak�m;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 740, 540);
		setVisible(true);
		setLocationRelativeTo(null);
		Color color2 = new Color(154,205,50);
		setBackground(color2);
		getContentPane().setLayout(new BorderLayout(0, 0));		
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(250, 250, 210));
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		Choice choice = new Choice();
		choice.setSize(111, 20);
		choice.setLocation(144, 10);
		choice.add("BESIKTAS");
		choice.add("GALATASARAY");
		choice.add("FENERBAHCE");		
		choice.add("TRABZONSPOR");
		panel.add(choice);
		
		JLabel label = new JLabel();
		label.setBackground(Color.WHITE);
		label.setBounds(294, 16, 140, 14);
		panel.add(label);
		
		JButton btnTakmDeitircem = new JButton("CHANGE THE TEAM");
		btnTakmDeitircem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Transfer frame = new Transfer();
					setVisible(false);
					dispose();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}				
			}
		});
		btnTakmDeitircem.setBounds(261, 9, 159, 23);
		panel.add(btnTakmDeitircem);
		
		
		
		txtTeamName = new JTextField();
		txtTeamName.setText("TEAM NAME:");
		txtTeamName.setBounds(65, 10, 78, 20);
		panel.add(txtTeamName);
		txtTeamName.setColumns(10);
		
		JButton btnBackToGame = new JButton("Back to Game Menu");
		btnBackToGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GameMenu frame = new GameMenu();
				setVisible(false);
				dispose();
			}
		});
		btnBackToGame.setBounds(467, 467, 127, 23);
		panel.add(btnBackToGame);
		
		JButton btnOnaylama = new JButton("btnOnaylama");
		btnOnaylama.setBounds(233, 467, 89, 23);
		panel.add(btnOnaylama);
		
		
		choice.addItemListener(new ItemListener(){
	        public void itemStateChanged(ItemEvent ie)
	        {
	        	label.setText("");
	        	repaint();
	        	
	        	label.setText(choice.getSelectedItem());
	        	secilenTak�m=label.getText();
	        	String Gonderilen = "SELECT * FROM PLAYER,�DCLUB WHERE CLUB�D=�DCLUB AND CLUB_NAME="+"'"+secilenTak�m+"'";
	    		try {
					SadeceIs�m.Veri�ek2(Gonderilen, "SURNAME");
				} catch (SQLException e) {
					e.printStackTrace();
				}
	    	
	    		int count = 30;
	 
	    		for(Object l : SadeceIs�m.list)
	    		{	
	    			source = new JCheckBox((String)l);
	    			source.setBounds(6, count, 140, 32);
	    			
	    			buttons.add(source);
	    			source.setOpaque(false);
	    			panel.add(source);
	    			count=count+22;	
					repaint();
    			
	    		}
	    		SadeceIs�m.list.clear();
	    		btnOnaylama.addActionListener(new ActionListener() {
	    			public void actionPerformed(ActionEvent arg0) {
	    				checkList.clear();
	    				for ( JCheckBox checkbox : buttons ) {
	    				    if( checkbox.isSelected() )
	    				    {
	    				    	checkList.add(checkbox.getText());
	    			    	
	    				    }
	    				}
	    			
	    			String Gonderilen2 = "SELECT * FROM PLAYER,�DCLUB WHERE CLUB�D=�DCLUB AND CLUB_NAME="+"'"+secilenTak�m+"'"+"AND SURNAME="+
	    					"'"+checkList.getFirst()+"'";

		    		try {
						SadeceIs�m.Veri�ek2(Gonderilen2, "UNIFORM_NO");
						for(Object l : SadeceIs�m.list)
			    		{				    			
			    			TransferIs�m=(String)l;
			    			/*try {
								TransferVeri.transferYap(se�ilenTak�m,TransferIs�m);
							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}*/
			    		}
					} catch (SQLException e) 
		    		{
						e.printStackTrace();
					}
		    		}
	    		});
	    		JLabel ArkaPlan = new JLabel(new ImageIcon("C:\\Users\\asus\\Desktop\\FMProje\\FMResimler\\stadium.jpg"));
	    		ArkaPlan.setBounds(0, 0, 724, 501);
	    		getContentPane().add(ArkaPlan);
	    		repaint();  
	    		
	        }
	    });		
		
	
	}
}
