package Gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.SystemColor;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import Veri.PlayerName;
import Veri.SadeceIs�m;

import java.awt.Font;

import javax.swing.JRadioButton;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JCheckBox;

import java.awt.Choice;

import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.Label;
import java.awt.Color;

public class TeamDesign extends JFrame {


	private JPanel contentPane;
	String pname2=null;
	String se�ilenTak�m;
	int count=19;
	int count2=0;
	JCheckBox source;
	private JTextField txtIlkiSeiniz;
	LinkedList checkList = new LinkedList();
	int sayiDeneme;
	int say�s�11=0;
	List<JCheckBox> buttons = new ArrayList<>();
	
	public TeamDesign() throws SQLException {
		super("IZTECH FM 15");
	 	this.se�ilenTak�m=NewGame.heptak�m;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 740, 540);
		setVisible(true);
		setLocationRelativeTo(null);
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		txtIlkiSeiniz = new JTextField();
		txtIlkiSeiniz.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtIlkiSeiniz.setForeground(new Color(0, 0, 0));
		txtIlkiSeiniz.setBackground(Color.LIGHT_GRAY);
		txtIlkiSeiniz.setText("\u0130lk 11'i Se\u00E7iniz");
		txtIlkiSeiniz.setHorizontalAlignment(SwingConstants.CENTER);
		txtIlkiSeiniz.setBounds(167, 11, 249, 22);
		panel.add(txtIlkiSeiniz);
		txtIlkiSeiniz.setColumns(10);
		
		
		
		String geciciTak�m="'"+NewGame.heptak�m+"'";
		String Gonderilen = "SELECT * FROM PLAYER,�DCLUB WHERE CLUB�D=�DCLUB AND CLUB_NAME="+geciciTak�m;
		SadeceIs�m.Veri�ek2(Gonderilen, "SURNAME");
		String pname = null;
		int count = 30;
	
		for(Object l : SadeceIs�m.list)
		{	

			source = new JCheckBox((String)l);
			source.setBounds(50, count, 140, 32);
			
			buttons.add(source);
			panel.add(source);
			count=count+22;	
			source.setOpaque(false);
			Color color=new Color(255,0,0);
			source.setForeground(color);
			source.setFont(new Font("Tahoma", Font.BOLD, 13));
			
		
		}
		
		
		JButton btnSeimiOnayla = new JButton("Se\u00E7imi Onayla");
		btnSeimiOnayla.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnSeimiOnayla.setForeground(Color.BLACK);
		btnSeimiOnayla.setBackground(Color.GRAY);
		btnSeimiOnayla.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				checkList.clear();
				for ( JCheckBox checkbox : buttons ) {
				    if( checkbox.isSelected() )
				    {
				    	checkList.add(checkbox.getText());
				    	
			    	
				    }
				}
				sayiDeneme=checkList.size();
				System.out.println(checkList.size());

				if(sayiDeneme!=11)
			    	
		    	{
					JOptionPane.showMessageDialog(new JFrame(), "Number of Players should be eleven");
		    	}
				else
				{
					for(Object xxx: checkList)
					{
						
						
						if(count2==0)
						{
							pname2="<html>"+xxx;	
							count2++;
						}					
						else 
						{
							pname2=pname2+"<br>"+xxx+"</br>";
							count2++;
						}
					}
					pname2=pname2+"</html>";
					JOptionPane.showMessageDialog(new JFrame(), pname2);

					
				}
				
			}
		});
		btnSeimiOnayla.setBounds(422, 405, 131, 85);
		panel.add(btnSeimiOnayla);
		
		
		
		JButton btnNewButton = new JButton("Back To Menu");
		btnNewButton.setBackground(Color.GRAY);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setOpaque(true);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				GameMenu frame = new GameMenu();
				setVisible(false);
				dispose();
			}
		});
		btnNewButton.setBounds(563, 405, 123, 85);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel(new ImageIcon("C:\\Users\\asus\\Desktop\\FMProje\\FMResimler\\saha.jpg"));
		lblNewLabel.setBounds(0, 0, 724, 501);
		panel.add(lblNewLabel);
		
		repaint();
		
	}
}
