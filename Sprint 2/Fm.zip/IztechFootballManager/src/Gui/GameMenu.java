package Gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.LayoutManager;
import java.awt.SystemColor;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.SQLException;

import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Font;

public class GameMenu extends JFrame {

	 String se�ilenTak�m;
	public GameMenu() {
		super("IZTECH FM 15");
		getContentPane().setBackground(Color.WHITE);
	 	this.se�ilenTak�m=NewGame.heptak�m;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 740, 540);
		setVisible(true);
		setLocationRelativeTo(null);
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 724, 1);
		panel.setBackground(Color.WHITE);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton teamButton = new JButton("TEAM");
		teamButton.setBackground(Color.GREEN);
		teamButton.setOpaque(false);
		teamButton.setBorderPainted(false);
		teamButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		teamButton.setForeground(Color.BLACK);
		teamButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					TeamDesign frame = new TeamDesign();
					frame.setVisible(true);
					dispose();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				
			}
		});

		teamButton.setBounds(111, 44, 191, 55);
		getContentPane().add(teamButton);
		
		JButton teamButton3 = new JButton("LEAGUE");
		teamButton3.setFont(new Font("Tahoma", Font.BOLD, 16));
		teamButton3.setBackground(Color.GREEN);
		teamButton3.setOpaque(false);
		teamButton3.setBorderPainted(false);
		teamButton3.setBounds(111, 155, 191, 55);
		getContentPane().add(teamButton3);
		
		JButton btnBudget = new JButton("FINANCE");
		btnBudget.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnBudget.setBackground(Color.GREEN);
		btnBudget.setOpaque(false);
		btnBudget.setBorderPainted(false);
		btnBudget.setBounds(111, 277, 191, 55);
		getContentPane().add(btnBudget);
		
		JButton teamButton4 = new JButton("TRANSFER");
		teamButton4.setOpaque(false);
		teamButton4.setBorderPainted(false);
		teamButton4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Transfer frame = new Transfer();
					frame.setVisible(true);
					dispose();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				
			}
		});
		teamButton4.setFont(new Font("Tahoma", Font.BOLD, 16));
		teamButton4.setBackground(Color.GREEN);
		teamButton4.setBounds(336, 100, 191, 55);
		getContentPane().add(teamButton4);
		
		JButton teamButton5 = new JButton("STADIUM");
		teamButton5.setFont(new Font("Tahoma", Font.BOLD, 16));
		teamButton5.setBackground(Color.GREEN);
		teamButton5.setOpaque(false);
		teamButton5.setBorderPainted(false);
		teamButton5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Stadium frame = new Stadium();
					frame.setVisible(true);
					dispose();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				
			}
		});
		teamButton5.setBounds(336, 220, 191, 55);
		getContentPane().add(teamButton5);
		
		JButton teamButton6 = new JButton("NEXT");
		teamButton6.setFont(new Font("Tahoma", Font.BOLD, 16));
		teamButton6.setBackground(Color.GRAY);
	
		teamButton6.setBounds(442, 416, 239, 55);
		getContentPane().add(teamButton6);
		
		JLabel arkaplan = new JLabel(new ImageIcon("C:\\Users\\asus\\Desktop\\FMProje\\FMResimler\\saha.jpg"));
		arkaplan.setBounds(0, 0, 724, 501);
		getContentPane().add(arkaplan);
		
		
	}
}
