package Gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

 class NewLoadGame extends JFrame
 {
	 private JPanel NewLoadGamePanel;
	 private JLabel NewLoadGameLabel;
	 public NewLoadGame()
	 {
		 	super("IZTECH FM 15");
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(100, 100,740,540);
			setVisible(true);
			setLocationRelativeTo(null);
			getContentPane().setLayout(new BorderLayout(0, 0));
			NewLoadGamePanel = new JPanel();	
			setContentPane(NewLoadGamePanel);
			NewLoadGamePanel.setLayout(null);
			
			NewLoadGameLabel = new JLabel(new ImageIcon("C:\\Users\\asus\\Desktop\\FMProje\\FMResimler\\NewLoadGame1.png"));
			NewLoadGameLabel.setBounds(0, 0, 724, 363);
			NewLoadGameLabel.setLayout(new FlowLayout());
			
			NewLoadGamePanel.add(NewLoadGameLabel);
			
			JButton newGameButton = new JButton("NEW GAME");
			newGameButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					try {
						NewGame NewGameFrame = new NewGame();
						NewGameFrame.setVisible(true);
						setVisible(false);	
						dispose();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			});
			newGameButton.setFont(new Font("Arial Black", Font.BOLD, 11));
			newGameButton.setBounds(0, 360, 724, 70);
			NewLoadGamePanel.add(newGameButton);
			
			JButton loadGameButton = new JButton("LOAD GAME");
			loadGameButton.setFont(new Font("Arial Black", Font.BOLD, 11));
			loadGameButton.setBounds(0, 431, 724, 70);
			NewLoadGamePanel.add(loadGameButton);
	 }
 }
 