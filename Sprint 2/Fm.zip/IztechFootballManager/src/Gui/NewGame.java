package Gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JRadioButton;
import javax.swing.JTextField;

import java.awt.Font;

import javax.swing.SwingConstants;

import java.awt.SystemColor;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.Enumeration;

public class NewGame extends JFrame {

	private JPanel NewGamePanel;
	static String heptak�m;

	public NewGame() {
		super("IZTECH FM 15");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 740, 540);
		setVisible(true);
		setLocationRelativeTo(null);
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		
		NewGamePanel = new JPanel();	
		NewGamePanel.setBorder(null);
		NewGamePanel.setBackground(Color.WHITE);
		setContentPane(NewGamePanel);
		NewGamePanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel(new ImageIcon("C:\\Users\\asus\\Desktop\\FMProje\\FMResimler\\stsl.png"));
		lblNewLabel.setBackground(Color.WHITE);
	    lblNewLabel.setBounds(270, 185, 135, 94);
	    NewGamePanel.add(lblNewLabel);
		
		JRadioButton team1 = new JRadioButton("AKHISAR BELEDIYESPOR");
		team1.setBackground(Color.WHITE);
		team1.setBounds(52, 70, 151, 23);
		NewGamePanel.add(team1);
			
		JRadioButton team2 = new JRadioButton("BALIKESIRSPOR");
		team2.setBackground(Color.WHITE);
		team2.setBounds(52, 110, 151, 23);
		NewGamePanel.add(team2);
		
		JRadioButton team3 = new JRadioButton("BESIKTAS");
		team3.setBackground(Color.WHITE);
		team3.setBounds(52, 150, 151, 23);
		NewGamePanel.add(team3);
		
		JRadioButton team4 = new JRadioButton("BURSASPOR");
		team4.setBackground(Color.WHITE);
		team4.setBounds(52, 190, 151, 23);
		NewGamePanel.add(team4);
		
		JRadioButton team5 = new JRadioButton("CAYKUR RIZESPOR");
		team5.setBackground(Color.WHITE);
		team5.setBounds(52, 230, 151, 23);
		NewGamePanel.add(team5);
		
		JRadioButton team6 = new JRadioButton("ESKISEHIRSPOR");
		team6.setBackground(Color.WHITE);
		team6.setBounds(52, 270, 151, 23);
		NewGamePanel.add(team6);
		
		JRadioButton team7 = new JRadioButton("FENERBAHCE");
		team7.setBackground(Color.WHITE);
		team7.setBounds(52, 310, 151, 23);
		NewGamePanel.add(team7);
		
		JRadioButton team8 = new JRadioButton("GALATASARAY");
		team8.setBackground(Color.WHITE);
		team8.setBounds(52, 350, 151, 23);
		NewGamePanel.add(team8);
		
		JRadioButton team9 = new JRadioButton("GAZIANTEPSPOR");
		team9.setBackground(Color.WHITE);
		team9.setBounds(52, 390, 151, 23);
		NewGamePanel.add(team9);
		
		JRadioButton team10 = new JRadioButton("GENCLERBIRLIGI");
		team10.setBackground(Color.WHITE);
		team10.setBounds(460, 70, 151, 23);
		NewGamePanel.add(team10);
		
		JRadioButton team11 = new JRadioButton("ISTANBUL BASAKSEHIRSPOR");
		team11.setBackground(Color.WHITE);
		team11.setBounds(460, 110, 165, 23);
		NewGamePanel.add(team11);
		
		JRadioButton team12 = new JRadioButton("KARDEMIR KARABUKSPOR");
		team12.setBackground(Color.WHITE);
		team12.setBounds(460, 150, 165, 23);
		NewGamePanel.add(team12);
		
		JRadioButton team13 = new JRadioButton("KASIMPASASPOR");
		team13.setBackground(Color.WHITE);
		team13.setBounds(460, 190, 151, 23);
		NewGamePanel.add(team13);
		
		JRadioButton team14 = new JRadioButton("MEDICANA SIVASSPOR");
		team14.setBackground(Color.WHITE);
		team14.setBounds(460, 230, 151, 23);
		NewGamePanel.add(team14);
		
		JRadioButton team15 = new JRadioButton("MERSIN IDMAN YURDU");
		team15.setBackground(Color.WHITE);
		team15.setBounds(460, 270, 151, 23);
		NewGamePanel.add(team15);
		
		JRadioButton team16 = new JRadioButton("SAI ERCIYESSPOR");
		team16.setBackground(Color.WHITE);
		team16.setBounds(460, 310, 151, 23);
		NewGamePanel.add(team16);
		
		JRadioButton team17 = new JRadioButton("TORKU KONYASPOR");
		team17.setBackground(Color.WHITE);
		team17.setBounds(460, 350,151, 23);
		NewGamePanel.add(team17);
		
		JRadioButton team18 = new JRadioButton("TRABZONSPOR");
		team18.setBackground(Color.WHITE);
		team18.setBounds(460, 390, 151, 23);
		NewGamePanel.add(team18);
		
		
		ButtonGroup bgroup = new ButtonGroup();
	    bgroup.add(team1);
	    bgroup.add(team2);
	    bgroup.add(team3);
	    bgroup.add(team4);
	    bgroup.add(team5);
	    bgroup.add(team6);
	    bgroup.add(team7);
	    bgroup.add(team8);
	    bgroup.add(team9);
	    bgroup.add(team10);
	    bgroup.add(team11);
	    bgroup.add(team12);
	    bgroup.add(team13);
	    bgroup.add(team14);
	    bgroup.add(team15);
	    bgroup.add(team16);
	    bgroup.add(team17);
	    bgroup.add(team18);

		
		JButton squadButton = new JButton("SQUAD");
		squadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Enumeration<AbstractButton> allRadioButton=bgroup.getElements();  
		        while(allRadioButton.hasMoreElements())  
		        {  
		           JRadioButton temp=(JRadioButton)allRadioButton.nextElement();  
		           if(temp.isSelected())  
		           {  
		        	   String se�ilenTak�m=temp.getText();
		        	   
		        	   
		        	   try {
		        		   
							Squad SquadFrame = new Squad(se�ilenTak�m);
							SquadFrame.setVisible(true);
							setVisible(false);
							dispose();
							
						} catch (Exception e1) {
							e1.printStackTrace();
						}
						
		           }  
		        }           
				
			}
		});
		squadButton.setForeground(Color.BLACK);
		squadButton.setBackground(Color.WHITE);
		squadButton.setBounds(108, 435, 220, 55);
		NewGamePanel.add(squadButton);
		
		JButton applyButton = new JButton("APPLY");
		applyButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Enumeration<AbstractButton> allRadioButton=bgroup.getElements();  
		        while(allRadioButton.hasMoreElements())  
		        {  
		           JRadioButton temp=(JRadioButton)allRadioButton.nextElement();  
		           if(temp.isSelected())  
		           {  
		        	   String se�ilenTak�m=temp.getText();
		        	   //JOptionPane.showMessageDialog(null,"You select : "+temp.getText());
		        	   try {
		        		   
							GameMenu frame4 = new GameMenu();
							heptak�m=se�ilenTak�m;
							frame4.setVisible(true);
							setVisible(false);					
						} catch (Exception e1) {
							e1.printStackTrace();
						}
		           }  
		        }            
		     }
			
		});
		applyButton.setForeground(Color.BLACK);
		applyButton.setBackground(Color.WHITE);
		applyButton.setBounds(364, 435, 220, 55);
		NewGamePanel.add(applyButton);	    
		
		JLabel NewGameLabel = new JLabel("TURKISH SUPER LEAGUE");
		NewGameLabel.setFont(new Font("Arial Black", Font.BOLD, 15));
		NewGameLabel.setBackground(Color.WHITE);
		NewGameLabel.setForeground(Color.BLACK);
		NewGameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		NewGameLabel.setBounds(207, 11, 257, 29);
		NewGamePanel.add(NewGameLabel);
	}
}
