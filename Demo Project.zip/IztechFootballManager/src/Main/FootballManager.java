package Main;

import java.awt.EventQueue;
import Gui.Intro;

//Oyun Bu Main Kodu ile ba�lar ve import edilen gui.Intro ile buradan ge�i� yap�l�r.

public class FootballManager {
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Intro IntroFrame = new Intro();
					IntroFrame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
