package Gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.imageio.*;
import javax.swing.*;

import sun.audio.*;

public class Intro extends JFrame {
	private JPanel IntroPanel;
	private JButton toNewLoadGame;
	private JLabel IntroLabel;
	
	public Intro() 
	{
		super("IZTECH FM 15");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 740, 540);
		setVisible(true);
		setLocationRelativeTo(null);
		getContentPane().setLayout(new BorderLayout(0, 0));
		IntroPanel = new JPanel();	
		setContentPane(IntroPanel);
		
		IntroLabel = new JLabel(new ImageIcon("C:\\Users\\asus\\Desktop\\FMProje\\FMResimler\\IntroImage1.png"));
		IntroLabel.setBounds(0, 0, 724, 371);
		IntroLabel.setLayout(new FlowLayout());
		
		IntroPanel.setLayout(null);
		IntroPanel.add(IntroLabel);
		
		ImageIcon img = new ImageIcon("C:\\Users\\asus\\Desktop\\FMProje\\FMResimler\\IntroImage2.jpg");
		JButton toNewLoadGame = new JButton(img);
		//Burada ki actionListener ile Yeni Pencere A��l�yor
		toNewLoadGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					NewLoadGame NewLoadGameFrame = new NewLoadGame();
					NewLoadGameFrame.setVisible(true);
					setVisible(false);
					dispose();
				} catch (Exception e1) {
					e1.printStackTrace();
				}				
			}
		});
		toNewLoadGame.setFont(new Font("Arial Black", Font.BOLD, 17));
		toNewLoadGame.setForeground(Color.BLACK);
		toNewLoadGame.setBounds(0, 368, 724, 133);
		IntroPanel.add(toNewLoadGame);
	}

}
