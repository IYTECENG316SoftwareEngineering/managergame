package Gui;

import java.awt.*;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.management.modelmbean.ModelMBean;
import javax.swing.*;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JTextField;

import java.awt.TextArea;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;

import javax.swing.SwingConstants;

import java.awt.Component;

import javax.swing.Box;

import Veri.PlayerName;


import java.awt.SystemColor;

 class Squad extends JFrame 
 {
	 public static int ko�ul=0;
	 String a[];
	 int i=0;
	 String se�ilenTak�m;
	 int count=0;
	 int count2=0;
	 int size=0;
 	
	 public Squad(String se�ilenTak�m) throws SQLException
	 {
		 		super("IZTECH FM 15");
		 		this.se�ilenTak�m=se�ilenTak�m;
			 	
				setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				setBounds(100, 100, 740, 540);
				setVisible(true);
				setLocationRelativeTo(null);
				getContentPane().setLayout(new BorderLayout(0, 0));
				
				JPanel squadPanel = new JPanel();
				squadPanel.setBackground(SystemColor.menu);
				getContentPane().add(squadPanel, BorderLayout.CENTER);
				squadPanel.setLayout(null);
				
				JLabel squadLabel = new JLabel();
				squadLabel.setFont(new Font("Arial Black", Font.BOLD, 16));
				squadLabel.setVerticalAlignment(SwingConstants.TOP);
				squadLabel.setHorizontalAlignment(SwingConstants.CENTER);
				squadLabel.setBackground(SystemColor.menu);
				squadLabel.setForeground(Color.BLACK);
				squadLabel.setBounds(10, 60, 352, 368);
				

				JLabel squadLabel2 = new JLabel();
				squadLabel2.setFont(new Font("Arial Black", Font.BOLD, 14));
				squadLabel2.setVerticalAlignment(SwingConstants.TOP);
				squadLabel2.setHorizontalAlignment(SwingConstants.CENTER);
				squadLabel2.setBackground(SystemColor.menu);
				squadLabel2.setForeground(Color.BLACK);
				squadLabel2.setBounds(372, 60, 352, 368);
				
				
				String Gonderilen = "SELECT * From PLAYER";

				PlayerName.Veri�ek(Gonderilen, "PNAME","PSURNAME","POSITION");
				String pname = null;
				String pname2 = null;
				for(Object l : PlayerName.list)
				{	
					if(size<51)
					{
						if(count==0)
						{
							pname="<html>"+(String)l;	
							count++;
						}					
						else if(count!=0 && count%3==0)
						{
							pname=pname+"<br>"+(String)l;
							count++;
						}
						else
						{				
							if(count==1 || count==2)
							{
								pname= pname +" "+ (String)l;
								
							}
							else if(count!=1 && count%3==1)
							{
								pname= pname +" "+ (String)l+" ";
								
							}
							else
							{
								pname= pname +" "+ (String)l+"</br>";
								
							}
							count++;
							
							
						}
						size++;
						
						

					}
					else 
					{
						if(count2==0)
						{
							pname2="<html>"+(String)l;	
							count2++;
						}					
						else if(count2!=0 && count2%3==0)
						{
							pname2=pname2+"<br>"+(String)l;
							count2++;
						}
						else
						{				
							if(count2==1 || count2==2)
							{
								pname2= pname2 +" "+ (String)l;
								
							}
							else if(count2!=1 && count2%3==1)
							{
								pname2= pname2 +" "+ (String)l+" ";
								
							}
							else
							{
								pname2= pname2 +" "+ (String)l+"</br>";
								
							}
							count2++;
							
							
						}
						size++;
						
					}
				}
				pname=pname+"</html>";
				pname2=pname2+"</html>";
				squadLabel.setText(pname);				
				squadPanel.add(squadLabel);
				squadLabel2.setText(pname2);				
				squadPanel.add(squadLabel2);
				JButton ReturnButton = new JButton("Return to Team Page");
				ReturnButton.setFont(new Font("Arial Black", Font.BOLD, 11));
				ReturnButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						NewGame NewGameFrame = new NewGame();
						setVisible(false);	
						dispose();
					}
				});
				ReturnButton.setForeground(Color.BLACK);
				ReturnButton.setBackground(SystemColor.inactiveCaptionBorder);
				ReturnButton.setBounds(124, 439, 493, 51);
				squadPanel.add(ReturnButton);
				
				JLabel squadTak�mAd� = new JLabel("");
				squadTak�mAd�.setFont(new Font("Arial Black", Font.BOLD | Font.ITALIC, 17));
				squadTak�mAd�.setForeground(Color.BLACK);
				squadTak�mAd�.setBackground(Color.WHITE);
				squadTak�mAd�.setHorizontalAlignment(SwingConstants.CENTER);
				squadTak�mAd�.setBounds(0, 11, 724, 39);
				squadTak�mAd�.setText(this.se�ilenTak�m);
				squadPanel.add(squadTak�mAd�);
				
				
	 
	 }
 }
			
 





		

			
		
			
	
			

